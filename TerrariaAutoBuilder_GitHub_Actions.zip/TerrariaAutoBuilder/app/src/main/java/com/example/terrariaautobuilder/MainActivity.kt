package com.example.terrariaautobuilder

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var selectedUri: Uri? = null
    private var blueprint: Blueprint? = null
    private lateinit var status: TextView
    private lateinit var preview: ImageView
    private lateinit var planText: TextView
    private lateinit var scanButton: Button
    private lateinit var confirmButton: Button

    private val PICK_IMAGE = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 32, 36, 24)
            setBackgroundColor(Color.rgb(245, 246, 248))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        content.addView(label("Terraria AutoBuilder", 26f, true))
        content.addView(label("Сборка 0.1 • Android 14+", 13f, false))
        status = label("Статус: схема не загружена", 15f, true)
        content.addView(status)

        val upload = button("1. Загрузить PNG из галереи") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/png"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(intent, PICK_IMAGE)
        }
        content.addView(upload)

        preview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.WHITE)
            contentDescription = "Предпросмотр PNG-схемы"
        }
        content.addView(preview, LinearLayout.LayoutParams(-1, 420).apply { topMargin = 16 })

        scanButton = button("2. Распознать схему") { scanImage() }
        scanButton.isEnabled = false
        content.addView(scanButton)

        planText = label("План строительства появится после анализа схемы.", 14f, false)
        content.addView(planText)

        content.addView(button("Открыть настройки специальных возможностей") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        content.addView(button("Включить плавающую панель поверх Terraria") {
            if (android.provider.Settings.canDrawOverlays(this)) {
                startService(Intent(this, FloatingPanelService::class.java))
                Toast.makeText(this, "Плавающая панель запущена", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(
                    android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
        })

        confirmButton = button("3. Подтвердить следующий этап") {
            Toast.makeText(this, "Пока доступен только просмотр плана. Касания в Terraria не отправляются.", Toast.LENGTH_LONG).show()
        }
        confirmButton.isEnabled = false
        content.addView(confirmButton)

        content.addView(label(
            "Безопасный режим: приложение пока анализирует PNG и готовит план. " +
            "Автоматическая расстановка не включена: сначала нужны калибровка игрового экрана, " +
            "сопоставление реальных блоков и проверка управления в вашей версии Terraria.",
            13f, false
        ))

        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun label(text: String, size: Float, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.rgb(35, 39, 45))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 12, 0, 12)
        }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            setOnClickListener { action() }
        }

    @Deprecated("Deprecated in Android API; retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                if (bitmap == null) throw IllegalArgumentException("Не удалось прочитать PNG")
                selectedUri = uri
                preview.setImageBitmap(bitmap)
                scanButton.isEnabled = true
                status.text = "Статус: PNG загружен • ${bitmap.width} × ${bitmap.height}"
            } catch (e: Exception) {
                Toast.makeText(this, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun scanImage() {
        val uri = selectedUri ?: return
        try {
            val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                ?: throw IllegalArgumentException("Не удалось открыть изображение")
            // Автооценка размера клетки эвристическая: подходит для пиксель-арта с повторяющимися цветами,
            // но не гарантирует правильный размер игрового блока для произвольного PNG.
            val estimatedCell = estimateCellSize(bitmap.width, bitmap.height)
            blueprint = BlueprintScanner.scan(bitmap, estimatedCell)
            val bp = blueprint!!
            status.text = "Статус: схема проанализирована"
            planText.text = "Оценка клетки PNG: $estimatedCell px\n" +
                "Размер карты: ${bp.width} × ${bp.height}\n" +
                "Непрозрачных клеток: ${bp.cells.size}\n\n" +
                "Материалы (предварительно):\n" +
                bp.cells.groupingBy { it.blockName }.eachCount().entries.joinToString("\n") { "${it.key}: ${it.value}" } +
                "\n\nВажно: названия материалов — приблизительное сопоставление цветов, не точное распознавание Terraria."
            confirmButton.isEnabled = bp.cells.isNotEmpty()
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка анализа: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun estimateCellSize(w: Int, h: Int): Int {
        // Эвристика начального масштаба, пользователь должен проверить сетку.
        val minSide = minOf(w, h)
        return when {
            minSide >= 512 -> 8
            minSide >= 256 -> 4
            minSide >= 128 -> 2
            else -> 1
        }
    }
}
