# Terraria AutoBuilder (Android prototype)

## Что включено
- Android Studio project scaffold (Kotlin).
- PNG import using Android document picker; no broad photo permission required.
- PNG preview.
- Basic pixel-grid scanner with a clearly illustrative color palette.
- Preliminary plan/material counts.
- Accessibility service declaration and a minimal tap primitive.

## Что НЕ реализовано
- Это не готовый APK и не полноценный автоматический строитель.
- Автоопределение масштаба пока эвристическое и требует проверки; оно не определяет реальные Terraria tiles.
- Нет захвата экрана/MediaProjection pipeline, распознавания игрового мира, инвентаря, выбора материалов, навигации, camera control или верификации размещённых блоков.
- Кнопка подтверждения намеренно не отправляет касания в игру. Это предотвращает случайные нажатия до калибровки.
- Wi-Fi ADB не используется: на одном телефоне он не нужен для этого прототипа.

## Сборка
1. Открой папку проекта в Android Studio (версия с поддержкой AGP 8.7.3).
2. Дождись Gradle Sync.
3. Собери и установи приложение на Android 14.
4. Выбери PNG через кнопку загрузки, затем запусти анализ.

Для реального строительства потребуется отдельная реализация калибровки, MediaProjection foreground service и подтверждаемого исполнительного контура.


## Floating overlay panel (prototype)
- Added Android overlay permission (`SYSTEM_ALERT_WINDOW`).
- Added `FloatingPanelService` with Build / Pause / Stop / close controls.
- Launch it from the main screen; Android asks the user to grant "Display over other apps".
- The buttons currently manage the panel's local demo state only. They do not place blocks in Terraria.
