package com.example.terrariaautobuilder

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.View

class FloatingPanelService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private var statusView: TextView? = null
    private var paused = false
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!android.provider.Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun showPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.argb(238, 28, 32, 38))
        }

        val title = TextView(this).apply {
            text = "Terraria AutoBuilder"
            setTextColor(Color.WHITE)
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setPadding(4, 2, 4, 8)
        }
        root.addView(title)

        statusView = TextView(this).apply {
            text = "Ожидание подтверждения"
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(4, 2, 4, 8)
        }
        root.addView(statusView)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        controls.addView(makeButton("Строить") {
            running = true
            paused = false
            statusView?.text = "Режим готовности: действия требуют подтверждения"
            // Здесь намеренно нет автоматических игровых касаний:
            // исполнитель должен быть подключён после калибровки.
        })
        controls.addView(makeButton("Пауза") {
            if (running) {
                paused = !paused
                statusView?.text = if (paused) "Пауза" else "Готово к подтверждению"
            } else {
                statusView?.text = "Строительство ещё не запущено"
            }
        })
        controls.addView(makeButton("Стоп") {
            running = false
            paused = false
            statusView?.text = "Остановлено"
        })
        controls.addView(makeButton("×") { stopSelf() })

        root.addView(controls)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16
            y = 120
        }

        panel = root
        try {
            windowManager.addView(root, params)
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun makeButton(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 10f
            isAllCaps = false
            setPadding(4, 0, 4, 0)
            minWidth = 0
            minimumWidth = 0
            setOnClickListener { action() }
        }

    override fun onDestroy() {
        panel?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        panel = null
        super.onDestroy()
    }
}
