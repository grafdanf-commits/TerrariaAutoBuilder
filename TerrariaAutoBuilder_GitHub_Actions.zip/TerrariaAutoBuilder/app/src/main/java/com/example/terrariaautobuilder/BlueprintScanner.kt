package com.example.terrariaautobuilder

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.sqrt

data class BlueprintCell(val x: Int, val y: Int, val color: Int, val blockName: String)
data class Blueprint(val width: Int, val height: Int, val cells: List<BlueprintCell>)

object BlueprintScanner {
    private data class Sample(val name: String, val color: Int)
    private val palette = listOf(
        Sample("Дерево (пример)", Color.rgb(130, 80, 45)),
        Sample("Камень (пример)", Color.rgb(110, 110, 110)),
        Sample("Земля (пример)", Color.rgb(120, 75, 45)),
        Sample("Песок (пример)", Color.rgb(220, 190, 120)),
        Sample("Стекло (пример)", Color.rgb(150, 210, 220)),
        Sample("Кирпич (пример)", Color.rgb(170, 75, 65)),
        Sample("Листва (пример)", Color.rgb(65, 145, 65))
    )

    fun scan(bitmap: Bitmap, cellSizePx: Int): Blueprint {
        require(cellSizePx in 1..256)
        val cols = (bitmap.width + cellSizePx - 1) / cellSizePx
        val rows = (bitmap.height + cellSizePx - 1) / cellSizePx
        val cells = mutableListOf<BlueprintCell>()

        for (cy in 0 until rows) for (cx in 0 until cols) {
            var r = 0L; var g = 0L; var b = 0L; var n = 0
            val xEnd = minOf((cx + 1) * cellSizePx, bitmap.width)
            val yEnd = minOf((cy + 1) * cellSizePx, bitmap.height)
            for (py in cy * cellSizePx until yEnd step maxOf(1, cellSizePx / 8)) {
                for (px in cx * cellSizePx until xEnd step maxOf(1, cellSizePx / 8)) {
                    val p = bitmap.getPixel(px, py)
                    if (Color.alpha(p) < 128) continue
                    r += Color.red(p); g += Color.green(p); b += Color.blue(p); n++
                }
            }
            if (n == 0) continue
            val avg = Color.rgb((r/n).toInt(), (g/n).toInt(), (b/n).toInt())
            val nearest = palette.minBy { distance(avg, it.color) }
            cells += BlueprintCell(cx, cy, avg, nearest.name)
        }
        return Blueprint(cols, rows, cells)
    }

    private fun distance(a: Int, b: Int): Double {
        val dr = Color.red(a)-Color.red(b)
        val dg = Color.green(a)-Color.green(b)
        val db = Color.blue(a)-Color.blue(b)
        return sqrt((dr*dr + dg*dg + db*db).toDouble())
    }
}
